	<div class="alert alert-<?= $status ?> alert-dismissible fade show" role="alert">
		<?= $notif_text ?>
		<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
	</div>